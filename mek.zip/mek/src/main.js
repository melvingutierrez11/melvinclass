import './styles/styles.less';

console.log("Portafolio con Vite y LESS cargado!");